<h1>Lista de Mensagens</h1>
<hr>
<h3><b>Titulo:</b>{{$msg->titulo}}</h3>
<h3><b>Texto:</b>{{$msg->texto}}</h3>
<h3><b>Autor:</b>{{$msg->autor}}</h3>
<h3><b>Criada em:</b>{{\Carbon\Carbon::parse($msg->created_at)->format('d/m/Y h:m')}}</h3>
