<h1>Lista de Mensagens</h1>
<hr>
@foreach($mensagens as $msg)
	<h3><a href="/mensagens/{{$msg->id}}">{{$msg->titulo}}</a></h3>
	<p>{{$msg->texto}}</p>
	<p>{{$msg->autor}}</p>
    <p>{{\Carbon\Carbon::parse($msg->created_at)->format('d/m/Y h:m')}}</p>
	<br>
@endforeach
