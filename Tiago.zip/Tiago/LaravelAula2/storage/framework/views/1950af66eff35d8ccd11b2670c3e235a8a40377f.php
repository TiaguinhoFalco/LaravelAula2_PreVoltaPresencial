<h1>Lista de Atividades</h1>
<hr>
<?php $__currentLoopData = $atividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h3><?php echo e(\Carbon\Carbon::parse($atividade->scheduledto)->format('d/m/Y h:m')); ?></h3>
	<p><a href="/atividades/<?php echo e($atividade->id); ?>"> <?php echo e($atividade->title); ?></a></p>
	<p><?php echo e($atividade->description); ?></p>
	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<!-- \Carbon\Carbon::parse($atividade->scheduledto)->format('d/m/Y h:m')  -->