<h1>Lista de Mensagens</h1>
<hr>
<?php $__currentLoopData = $mensagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h3><a href="/mensagens/<?php echo e($msg->id); ?>"><?php echo e($msg->titulo); ?></a></h3>
	<p><?php echo e($msg->texto); ?></p>
	<p><?php echo e($msg->autor); ?></p>
    <p><?php echo e(\Carbon\Carbon::parse($msg->created_at)->format('d/m/Y h:m')); ?></p>
	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
