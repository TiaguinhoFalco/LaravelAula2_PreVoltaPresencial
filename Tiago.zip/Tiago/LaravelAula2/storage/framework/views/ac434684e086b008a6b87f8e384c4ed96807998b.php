<h1>Atividades <?php echo e($atividade->id); ?></h1>
<hr>
<h3><b>ID:</b><?php echo e($atividade->id); ?></h3>
<h3><b>Titulo:</b><?php echo e($atividade->title); ?></h3>
<h3><b>Descrição:</b><?php echo e($atividade->description); ?></h3>
<h3><b>Criada em:</b><?php echo e(\Carbon\Carbon::parse($atividade->created_at)->format('d/m/Y h:m')); ?></h3>
<h3><b>Atualizada em:</b><?php echo e(\Carbon\Carbon::parse($atividade->updated_at)->format('d/m/Y h:m')); ?></h3>
