<h1>Lista de Mensagens</h1>
<hr>
<h3><b>Titulo:</b><?php echo e($msg->titulo); ?></h3>
<h3><b>Texto:</b><?php echo e($msg->texto); ?></h3>
<h3><b>Autor:</b><?php echo e($msg->autor); ?></h3>
<h3><b>Criada em:</b><?php echo e(\Carbon\Carbon::parse($msg->created_at)->format('d/m/Y h:m')); ?></h3>
