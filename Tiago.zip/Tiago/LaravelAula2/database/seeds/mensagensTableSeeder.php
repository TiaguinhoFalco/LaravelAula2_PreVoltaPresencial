<?php

use Illuminate\Database\Seeder;
use App\Mensagem;

class mensagensTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Mensagem::create([
            'titulo' => 'Olá...',
            'texto' => '...Mundo',
            'autor' => 'Eu'
        ]);

        Mensagem::create([
            'titulo' => 'Tchau...',
            'texto' => '...Mundo',
            'autor' => 'Eu novamente'
        ]);

        
    }
}
